package com.paytm;
public class PaytmConstants {
  public final static String MID="GUoqQm83762846235375";
  public final static String MERCHANT_KEY="PXFAbSr7WG%nVBwb";
  public final static String INDUSTRY_TYPE_ID="Retail";
  public final static String CHANNEL_ID="WEB";
  public final static String WEBSITE="WEBSTAGING";
  public final static String PAYTM_URL="https://securegw-stage.paytm.in/theia/processTransaction"; 
  
}
